"""Prompt library app package."""
